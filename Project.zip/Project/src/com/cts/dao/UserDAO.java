package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.cts.dao.UserDAO;

public class UserDAO {

	private static Connection con = null;
	private ResultSet rs = null;
	private Statement st = null;
	

	
	public int validUser(String id, String password)
	{
		
	
		int count = 0;
		
			try {
				UserDAO.connect();
				String sql = "Select * from user_details where EmployeeId=? and password=?";
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setString(1, id);
				ps.setString(2, password);
				
				System.out.println(id + " " + password);
				
				ResultSet rs = ps.executeQuery();
				
				
				while (rs.next())
				{
					count = 1;
				}
				
					
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return count;
	}
	
	public static Connection connect() throws Exception
	{
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/user_information","root","root");
		return con;
	}
	

}
