package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.cts.bean.Vehicle;

public class VehicleDAO {

	private static Connection con = null;
	private ResultSet rs = null;
	private Statement st = null;
	private PreparedStatement ps = null;

	public int insert(Vehicle v) throws Exception 
	{
		int insertStatus = 0;
		try {
			VehicleDAO.connect();
			ps = con.prepareStatement("insert into user_details values (?,?)");
			
			
			ps.setString(1, v.getUserId());
			ps.setString(8, v.getPassword());
			
			
			insertStatus = ps.executeUpdate();	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
		if(con != null)
			con.close();
		}
		return insertStatus;
			
		}
	

	
	public static Connection connect() throws Exception
	{
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/user_information","root","root");
		return con;
	}
}
